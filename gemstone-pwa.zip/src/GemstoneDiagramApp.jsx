import { useState } from "react";

export default function GemstoneDiagramApp() {
  const [selectedCut, setSelectedCut] = useState("round");

  const gemstoneImages = {
    round: "/images/round_brilliant.png",
    oval: "/images/oval_cut.png",
    pear: "/images/pear_cut.png",
    marquise: "/images/marquise.png",
    emerald: "/images/emerald_cut.png",
    trillion: "/images/trillion_cut.png",
  };

  return (
    <div>
      <h1>Edelstein-Facetten Diagramm</h1>
      <select onChange={(e) => setSelectedCut(e.target.value)} value={selectedCut}>
        <option value="round">Rund</option>
        <option value="oval">Oval</option>
        <option value="pear">Tropfen</option>
        <option value="marquise">Marquise</option>
        <option value="emerald">Smaragd</option>
        <option value="trillion">Trillion</option>
      </select>
      <div>
        <img src={gemstoneImages[selectedCut]} alt="Diagramm" width="300" />
      </div>
    </div>
  );
}

if (typeof window !== "undefined" && 'serviceWorker' in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/service-worker.js").then((reg) => {
      console.log("SW registered: ", reg.scope);
    }).catch((err) => {
      console.error("SW registration failed: ", err);
    });
  });
}
